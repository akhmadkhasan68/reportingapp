<?php $__env->startSection('title', 'Detail Pengaduan '.ucwords($report->name)); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
        <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
    </div>

    <?php 
        if($report->status == 0)
        {
            $note = 'Belum Diriview'; 
            $color = 'warning';
        }
        elseif($report->status == 1) {
            $note = 'Sudah Diriview'; 
            $color = 'success';
        }
        else{
            $note = 'Ditolak'; 
            $color = 'danger';
        }
    ?>

    <div class="row">
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-12 col-md-12 ">
            <div class="alert alert-<?php echo e($color); ?>">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="font-weight-bold text-<?php echo e($color); ?> text-uppercase mb-1">
                            Info</div>
                        <p class="text-default">
                            Data pelaporan ini dalam status <b><?php echo e($note); ?></b>
                        </p>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-info-circle fa-2x text-<?php echo e($color); ?>"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-12 col-md-12 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Voters</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($report->votes->count()); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-12">
            <div class="card mb-3">
                <div class="card-header">
                    Data Gambar
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <th width="2%">No</th>
                                <th>Gambar</th>
                            </thead>
                            <tbody>
                                <?php $no=1; ?>
                                <?php $__currentLoopData = $report->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><a href="#"><?php echo e($image->photo); ?></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><?php echo $__env->yieldContent('title'); ?></div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th>Nama</th>
                                <td><?php echo e($report->name); ?></td>
                            </tr>
                            <tr>
                                <th>Deskripsi</th>
                                <td><?php echo e($report->description); ?></td>
                            </tr>
                            <tr>
                                <th>Tempat Kejadian</th>
                                <td>
                                    <?php echo e($report->address); ?>, <?php echo e($report->village->name); ?>, <?php echo e($report->district->name); ?>, <?php echo e($report->regency->name); ?>, <?php echo e($report->province->name); ?>

                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if($report->status == 0): ?>
        <div class="row mt-3">
            <div class="col-xl-6 col-12">
                <button class="btn btn-block btn-danger" onclick="changeStatus(2, `<?php echo e($report->id); ?>`)"><i class="fa fa-times-circle"></i> Tolak</button>
            </div>
            <div class="col-xl-6 col-12">
                <button class="btn btn-block btn-success" onclick="changeStatus(1, `<?php echo e($report->id); ?>`)"><i class="fa fa-check-circle"></i> Terima</button>
            </div>
        </div>
    <?php else: ?>
        <div class="row mt-3">
            <div class="col-xl-12 col-12">
                <a href="<?php echo e(route('reports.index')); ?>" class="btn btn-block btn-danger"><i class="fa fa-chevron-left"></i> Kembali</a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    const changeStatus = (status, id) => {
        Swal.fire({
            title: 'Yakin?',
            text: "Ingin menghapus data ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Tidak',
            confirmButtonText: 'Ya!'
        }).then((result) => {
            if (result.value) {
                new Promise((resolve, reject) => {
                    let url = `<?php echo e(route('reports.update', ':id')); ?>`;
                    url = url.replace(':id', id);

                    $.ajaxSetup({
                        headers:
                        { 'X-CSRF-TOKEN': csrf}
                    });
        
                    $.ajax({
                        url: url,
                        method: "PATCH",
                        data: {
                            status: status
                        }
                    })
                    .then(res => {
                        if(res.success === false)
                        {
                            Object.entries(res.message)
                            .map(([, fieldErrors]) => 
                                fieldErrors.map(fieldError => toastr.error(`${fieldError}`, 'Gagal'))
                            )
                        }else
                        {
                            toastr.success(`Berhasil`, 'Sukses');
                            
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        }
                    })
                    .catch(err => {
                        alert('error');
                    })
                })
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/reporting/resources/views/admin/reports/detail.blade.php ENDPATH**/ ?>