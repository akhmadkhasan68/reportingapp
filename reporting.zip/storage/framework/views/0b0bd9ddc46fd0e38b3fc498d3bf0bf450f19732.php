<?php if($reports->count() > 0): ?>
    <?php $no = 1; ?>
    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($report->name); ?></td>
            <td><?php echo e($report->description); ?></td>
            <td><?php echo e($report->votes_count); ?></td>
            <td><?php if($report->status == 0): ?> <span class="badge badge-warning">Belum Diriview</span> <?php elseif($report->status == 1): ?> <span class="badge badge-success">Diterima</span> <?php else: ?> <span class="badge badge-danger">Ditolak</span> <?php endif; ?></td>
            <td>
                <a href="<?php echo e(route('reports.show', $report->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                <button class="btn btn-danger btn-sm" onclick="deleteData(`<?php echo e(route('reports.destroy', $report->id)); ?>`)">Hapus</button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <tr>
        <td colspan="6">
            <center>Data Kosong!</center>
        </td>
    </tr>
<?php endif; ?><?php /**PATH /var/www/reporting/resources/views/admin/reports/table.blade.php ENDPATH**/ ?>